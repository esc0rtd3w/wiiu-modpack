<?php

$wiiuhaxxcfg_payloadfilepath = "code532.bin";
$wiiuhaxxcfg_loaderfilepath = "wiiuhaxx_loader.bin";

?>