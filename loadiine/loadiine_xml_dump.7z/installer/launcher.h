#ifndef LAUNCHER_H
#define LAUNCHER_H

/* Include base types */
#include "../src/common/types.h"

#endif /* LAUNCHER_H */
