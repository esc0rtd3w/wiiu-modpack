#!/usr/bin/env python
import socket
import struct

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 12345))
s.listen(1)
conn, addr = s.accept()
print('Connected by ', addr)

elf_data = open('loadiine.elf', 'rb').read()
size = len(elf_data)
print('Sending {} bytes'.format(size))

size_packet = struct.pack('>I', size)
conn.send(size_packet)
conn.sendall(elf_data)

while True:
	data = conn.recv(512)

	if data:
		print(data)
