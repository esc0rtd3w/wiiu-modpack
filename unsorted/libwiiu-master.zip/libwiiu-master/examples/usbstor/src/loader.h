#ifndef LOADER_H
#define LOADER_H

#include "../../../libwiiu/src/types.h"
#include "../../../libwiiu/src/coreinit.h"
#include "../../../libwiiu/src/uhs.h"

void _start();

void _entryPoint();
#endif /* LOADER_H */