#include "loader.h"

void _start()
{
	OSFatal("Hello World!\n");
}