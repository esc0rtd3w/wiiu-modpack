#ifndef PROGRAM_H
#define PROGRAM_H
#include "../../../libwiiu/src/coreinit.h"
#include "../../../libwiiu/src/types.h"
#include "../../../libwiiu/src/draw.h"

void _entryPoint();

#endif /* PROGRAM_H */