#ifndef STRING_H
#define STRING_H

int strlen(const char *str);

#endif /* STRING_H*/