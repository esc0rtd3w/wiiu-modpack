#ifndef MATH_H
#define MATH_H

long abs(long value);

#endif /* MATH_H */