#ifndef LOADER_H
#define LOADER_H

void _main();
void _osscreeninit();
void _printstr(char *str);
void _osscreenexit();

#endif /* LOADER_H */