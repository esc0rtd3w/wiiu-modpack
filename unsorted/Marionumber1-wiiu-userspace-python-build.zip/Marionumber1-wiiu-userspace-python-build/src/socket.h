#define AF_INET		2
#define SOCK_STREAM	1
#define IPPROTO_TCP	6

struct in_addr
{
  unsigned long s_addr;
};

struct sockaddr
{
  unsigned short sin_family;
  unsigned short sin_port;
  struct in_addr sin_addr;
  char sin_zero[8];
};

/* IP address of the RPC client (in this case, 192.168.1.4) */
#define PC_IP	0xC0A80104
