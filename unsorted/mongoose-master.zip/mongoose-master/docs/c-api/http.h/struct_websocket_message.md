---
title: "struct websocket_message"
decl_name: "struct websocket_message"
symbol_kind: "struct"
signature: |
  struct websocket_message {
    unsigned char *data;
    size_t size;
    unsigned char flags;
  };
---

WebSocket message 

