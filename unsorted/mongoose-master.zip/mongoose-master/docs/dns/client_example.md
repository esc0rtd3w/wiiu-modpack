---
title: DNS client example
---

TBD
