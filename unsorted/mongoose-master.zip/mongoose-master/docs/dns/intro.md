---
title: DNS
items:
  - { name: server_example.md }
  - { name: client_example.md }
  - { name: ../c-api/dns.h/ }
  - { name: ../c-api/dns_server.h/ }
---
