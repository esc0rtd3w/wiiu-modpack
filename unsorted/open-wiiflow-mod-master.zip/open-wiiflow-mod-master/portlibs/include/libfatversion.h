#ifndef __LIBFATVERSION_H__
#define __LIBFATVERSION_H__

#define _LIBFAT_MAJOR_	1
#define _LIBFAT_MINOR_	0
#define _LIBFAT_PATCH_	12

#define _LIBFAT_STRING "libFAT Release 1.0.12"

#endif // __LIBFATVERSION_H__
