Copyright 2011  Dimok
This code is licensed to you under the terms of the GNU GPL, version 2;
see file COPYING or http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt

Compile:
Requires devkitPPC R17 (not working with R18+).