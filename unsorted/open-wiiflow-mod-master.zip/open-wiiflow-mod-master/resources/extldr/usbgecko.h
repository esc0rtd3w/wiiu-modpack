#ifndef __USBGECKO_H__
#define __USBGECKO_H__

void usbgecko_init();
void gprintf(const char* string);

#endif
