#ifndef STRING_H_
#define STRING_H_

void * _memcpy(void *dst, const void *src, u32 len);
void * _memset(void *b, u8 c, u32 len);

#endif
