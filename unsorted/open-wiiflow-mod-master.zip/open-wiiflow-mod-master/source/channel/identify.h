#ifdef __cplusplus
extern "C"
{
#endif

#ifndef _PATCHER_H_
#define _PATCHER_H_

void PatchIOS(bool patch_all);

#endif

#ifdef __cplusplus
}
#endif
