#define size_dip_plugin_249 5680

extern unsigned char dip_plugin_249[5680];
