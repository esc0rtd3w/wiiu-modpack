#define size_sdhc_module 5672

extern unsigned char sdhc_module[5672];
