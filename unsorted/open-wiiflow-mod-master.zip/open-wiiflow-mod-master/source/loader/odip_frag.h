#define size_odip_frag 9120

extern unsigned char odip_frag[9120];
