#ifndef __LANGUAGE_CODE_H_
#define __LANGUAGE_CODE_H_

#ifdef __cplusplus
extern "C" {
#endif

const char* CONF_GetLanguageString(void);

#ifdef __cplusplus
}
#endif

#endif
