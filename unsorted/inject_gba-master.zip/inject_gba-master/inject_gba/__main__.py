# -*- coding: utf-8 -*-
 
"""inject_gba.__main__: executed when inject_gba directory is called as script."""
 
from .inject_gba import main
main()
