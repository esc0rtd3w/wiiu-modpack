# -*- coding: utf-8 -*-
 
"""inject_gba.__init__"""
