
#ifndef _IPL_H_
#define _IPL_H_

void load_ipl(unsigned char *buf);

#endif
