
#ifndef __HID_H__
#define __HID_H__

void HIDUpdateRegisters();

#endif
