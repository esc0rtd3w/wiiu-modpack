
#ifndef _HIDMEM_H_
#define _HIDMEM_H_
static controller *HID_CTRL = (controller*)0x93005000;
static u8 *HID_Packet = (u8*)0x930050F0;
#endif
