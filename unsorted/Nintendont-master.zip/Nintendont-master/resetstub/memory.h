#ifndef __MEMORY_H__
#define __MEMORY_H__

void __temp_abe(void);
void ICInvalidateRange(void *, int);
void DCFlashInvalidate(void *, int);

#endif

