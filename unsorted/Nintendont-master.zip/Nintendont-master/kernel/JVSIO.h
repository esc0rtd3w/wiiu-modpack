#ifndef __JVSIO_H__
#define __JVSIO_H__

#include "global.h"

#define		TRIButtons		0x13002708

void JVSIOCommand( char *DataIn, char *DataOut );

#endif
