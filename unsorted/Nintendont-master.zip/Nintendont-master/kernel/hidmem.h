
#ifndef _HIDMEM_H_
#define _HIDMEM_H_
static controller *HID_CTRL = (controller*)0x13005000;
static void *HID_Packet = (void*)0x130050F0;
#endif
