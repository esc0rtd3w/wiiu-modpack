DEVOLUTION: What is it and how do you use it?

Devolution is a loader designed to run Gamecube games on a Wii. Dolphin was the codename
for the Gamecube, Revolution was the codename for the Wii, add them together = Devolution.
Although most Wii models include backwards compatibility for Gamecube games it is rather
limited; support for several Gamecube peripherals is missing, the original wired
controllers must be used, unreliable memory cards are still required for saving games...
It seemed like it should be possible to do things better. So I did...

Devolution currently offers the following enhancements to the regular "Gamecube on Wii"
experience:
- Alternative mediums for loading games (SD and USB)
- Alternative controllers (Wiimote with classic controller, WiiU Pro Controller, PS3
controller, OUYA controller, XBOX360 wired controller+chatpad, USB/BT keyboard, WiiU
USB Gamecube Adapter)
- Alternative mediums as memory cards (SD / USB / NAND)
- Emulation of the Gamecube modem hardware using the Wii's networking hardware (wifi or
wired) for online play
- Emulation of the Gamecube BBA hardware using the Wii's networking hardware (wifi or
wired) for LAN play
- Wii Family Edition and WiiU support
- Screenshot captures
- Playtime recording on the system menu's daily log
- Horizontal stretching to accomodate underscan areas on newer TVs.

To get started using Devolution you need a GC compatible Wii with working disc drive and
HBC installed, some physical Gamecube games and their matching .iso files (stored in a
directory called /games on a USB drive or SD card) and the Devolution sample loader app
(which was in the .zip file with this readme). 
The following process describes how to load an individual game for the first time:
Step 1: Remove any discs from the Wii.
Step 2: Launch the Devolution loader app from HBC.
Step 3: Press Y or X to mount a USB drive or SD card, depending on what you're using to
store your games (if using a Wiimote press 1 or 2; if using a Classic Controller press x
or a). 
Step 4: Use the DPAD to scroll up or down through the .iso files in your /games directory
until you've decided which one to play. Press A (b on a classic controller) to launch it
and the screen should go blank; a short time later the blue slot led should repeatedly
flash twice followed by staying off for a few seconds.
Step 5 (OPTIONAL): If you plan on playing the game on other Wii or WiiU consoles, you will
need to connect one or more wiimotes to the wii now. If the wiimotes are not currently
paired with this Wii just press the red sync button on both the wii and the wiimote and
wait for it to connect. Once connected it should have one light flashing on and off
repeatedly.
Step 6: Insert the original Gamecube disc for the game you are loading. The wii should
read it for a few seconds then the slot led should flash five times.
Step 7: After a short wait the game should start. If instead Devolution exits back to
HBC, check to make sure the .iso file is a clean, identical copy of the disc's data.

In the future when you launch this game using Devolution it should start without needing
to insert the original disc. However if you launch the game on a different Wii/WiiU, you
will need to perform Step 5 (connect one of the same wiimotes used in the original
process) instead of being able to skip boths Steps 5 and 6. Only wiimotes may be used for
this purpose, not WiiU Pro controllers nor PS3/OUYA/XBOX controllers. No guarantees are made
for the behaviour of third-party wiimotes.

If you wish to repeat the original process for a game that has already been played (for
example to link it with different wiimotes), remove any discs from the wii and hold the
reset button when you choose the game to launch. Release the reset button only when the
slot led starts the two-flashes sequence and continue from Step 5.
Note that any games verified prior to Devolution r200 (the first build with wiimote
support) must be re-verified for use with r200 or later. Games verified with later versions
of Devolution will not be compatible with earlier versions of Devolution.

Analog sticks on all controllers are calibrated when they are first connected. Make
sure the sticks are in the neutral position when plugging in PS3 USB / classic / XBOX
controllers or wirelessly connecting PS3 BT / WiiU Pro / OUYA controllers. If a stick is not
centered correctly you will need to disconnect the controller and reconnect it.

If a WiiU USB Gamecube adapter is detected it will act as a substitute for real
Gamecube controller ports. Each individual slot can still be emulated by other controllers.
The USB Gamecube adapter supports wired/wavebird controllers only, it does not support
the GBA link cable or Gamecube keyboard. If the grey USB cable is not connected the USB
Gamecube adapter will not support rumble for wired controllers (wavebird controllers do
not have a rumble feature).

While a game is running, a connected controller can be active or inactive. If it has a
constantly lit LED it is currently active and will send input to the game. If the LED is
flashing on and off, it is inactive (this is the default state).
The position of the LED indicates which Gamecube slot the controller is currently tied
to. The HOME button (or PS/OUYA/XBOX button) is used to toggle between active/inactive
states. A Wiimote by itself cannot go active, it must have a classic controller (either
original or pro) attached.
When a controller is inactive there are several key sequences that perform special
functions (see below for OUYA and XBOX combinations):
- PLUS/START: change the controller's Gamecube slot to the next available (inactive) slot.
- MINUS/SELECT + DPAD LEFT: Toggle the global widescreeen setting.
- MINUS/SELECT + DPAD UP: If the game is currently asking to switch discs, load the
next .iso file (performs the same function as pressing the Eject button).
- MINUS/SELECT + DPAD DOWN: Simulate pressing the Gamecube's Reset button.
- MINUS/SELECT + DPAD RIGHT: Toggle the Slot Led activity indicator setting.
- MINUS/SELECT + A/CIRCLE: Toggle the global rumble setting for all emulated controllers. 
This can be used to override the system global Wiimote rumble setting (which is set by
bringing up the home screen for any official wii software).
- MINUS/SELECT + B/CROSS: Toggle the screen dimmer.

PS3 controllers support two extra functions:
- L1 + R1: When the PS3 controller is connected to the wii via USB this will write the
wii's Bluetooth address to the controller's memory so it can be used wirelessly. This only
needs to be done once (until the address is overwritten).
- L3 + R3: Exit Devolution (performs the same function as pressing the power button).

OUYA controllers support the following functions when inactive:
- Touchpad single press: change the controller's Gamecube slot to the next available
(inactive) slot.
- Home button hold/long press: Exit Devolution.
- L1 + DPAD LEFT: Toggle the global widescreen setting.
- L1 + DPAD UP: If the game is currently asking to switch discs, load the next .iso file
(performs the same function as pressing the Eject button).
- L1 + DPAD DOWN: Simulate pressing the Gamecube's Reset button.
- L1 + DPAD RIGHT: Toggle the Slot Led activity indicator setting.
- L1 + A: Toggle the global rumble setting for all emulated controllers.
- L1 + O: Toggle the screen dimmer.
The OUYA controller indicates the current Gamecube controller slot that it is connected to
by the number of LEDs lit on the controller rather than the position of a single LED i.e.
1 LED = slot 1, 2 LEDs = slot 2 etc.
When the OUYA controller is active the L1 or R3 (right-stick click) function as the start
button. The OUYA controller does not support rumble since it has no motor.

XBOX 360 controllers support the following functions when inactive:
- START: change the controller's Gamecube slot to the next available (inactive) slot.
- L3 + R3: Exit Devolution.
- BACK + DPAD LEFT: Toggle the global widescreen setting.
- BACK + DPAD UP: If the game is currently asking to switch discs, load the next .iso file.
- BACK + DPAD DOWN: Simulate pressing the Gamecube's Reset button.
- BACK + DPAD RIGHT: Toggle the Slot Led activity indicator setting.
- BACK + B: Toggle the global rumble setting for all emulated controllers.
- BACK + A: Toggle the screen dimmer.
The XBOX 360 controller supports rumble and use of the analog triggers. The default button
mapping is as follows:
XBOX A = Gamecube A
XBOX B = Gamecube X
XBOX Y = Gamecube Y
XBOX X = Gamecube B
If the CONFIG_D_BUTTONS flag is used the following mapping will apply:
XBOX A = Gamecube B
XBOX B = Gamecube A
XBOX Y = Gamecube X
XBOX Y = Gamecube Y
Only original wired XBOX 360 controllers are supported, third party wired controllers may
work but have not been tested. XBOX 360 wireless USB dongles or wireless controllers are
not supported.

When a WiiU Pro or Wiimote+Classic Controller is active, pressing the L button (or ZL for 
the original classic controller) will toggle the "C-Stick Trigger" mode - when it is
active, pressing the right stick up emulates pressing the right analog trigger and
pressing the right stick down emulates pressing the left analog trigger.
PS3, OUYA and XBOX controllers fully support emulating the Gamecube controller's analog
triggers by using their own triggers.

For Wiimotes and the WiiU Pro controller, pressing the power button simulates pressing the
console's power button and will exit Devolution. This simulation is performed by the
hardware, such as when a Wiimote is used to turn the console on.

New Wii controllers can be synced to the Wii at any time by pressing both red sync
buttons. Do not attempt to use the "1+2" syncing method. Note that the controllers
probably won't stay paired to the wii after exiting Devolution since it doesn't touch the 
wiimote records in the system files. However the wiimotes should support one-touch
reconnection while Devolution is running.

When using a Wiimote+Classic Controller, the Wiimote will rumble to match the emulated
Gamecube controller - this is intentional, since there are "retro" classic controllers
that feature a built-in Wiimote. There's no way to distinguish them from the software's
point of view.

PS3 controllers support both Bluetooth (wireless) and USB (wired) connections. A USB
connection must be used first so the Wii's BT address can be written to the controller (by
pressing L1 and R1 together). L2 and R2 are fully functional as analog triggers.

The battery state for Wiimote/OUYA controllers is monitored while they are active, if the
battery is sensed to be low the LEDs will blink off-on every 10 seconds.

A USB or Bluetooth keyboard can also be connected to emulate a Gamecube keyboard.
Control + Alt + F12/Return/Enter is used to toggle the keyboard between active and inactive
states. It also supports these special functions:
- Control + Alt + Delete/Numpad.: Exit Devolution.
- Control + Alt + Left: Widescreen toggle.
- Control + Alt + Up: Simulate Eject button (for disc swap).
- Control + Alt + Down: Simulate Reset button.
- Control + Alt + Right: Slot LED activity indicator toggle.
- Control + Alt + A: Toggle the global rumble setting for all emulated controllers.
- Control + Alt + B: Toggle the screen dimmer.
To connect a keyboard via Bluetooth press the red sync button on the wii followed by
the sync/connect button on the keyboard. You can test if the keyboard is connected
by toggling the capslock or numlock and checking if the status LEDs on the keyboard
change.

A chatpad fitted to a wired XBOX360 controller can also be used to emulate a Gamecube
keyboard. GREEN button + Enter is used to toggle the chatpad between active and inactive
states. It has no other special functions since they can be accessed using the attached
controller. Only the first detected wired XBOX360 controller can be used with a chatpad.
An attached chatpad always occupies a Gamecube controller slot, even when inactive. To
free the slot for use with other controllers the chatpad must be detached.

To capture a screenshot of the currently running game your wii must be connected to a
network (using either wifi or a wired adapter). Using a PC on the same network, open
a web browser and enter the wii's IP address in the address bar. If you're using a
windows PC with windows networking enabled (or the computer's operating system supports
NETBIOS name lookups) you can just enter "gc_devo" instead of the IP address, which
should automatically find the Wii. A page should appear showing the current disc's name
and three links at the bottom:
- XFB Screenshot: This will show the current game screen inside the web browser.
- 5s Auto Refresh: The same as XFB Screenshot, but will automatically refresh every 5
seconds.
- Direct Download: This links directly to the current game screen as a .BMP file, for
easy downloading to the PC.
The resolution of the screenshot depends on the current size of the framebuffer being
used by the game, there is no scaling applied. Note that retrieving screenshots may
cause minor interruptions to gameplay or audio playback.

BBA Emulation is supported for the following games that use LAN play:
- Mario Kart Double Dash
- Kirby's Air Ride
- 1080 Avalanche
Mixing systems that use wired and wireless networking may work but is not recommended
due to games using TTL (time-to-live) values of 1, which may prevent data packets
from being forwarded between networks.
LAN play/BBA emulation is compatible with Gamecubes using real BBA hardware.

The following games have their own specialized widescreen patches, this means they
should properly support 16:9 mode without any glitches or bad behaviour often observed
when using the generic widescreen patch:
- Phantasy Star Online (Episode 1+2)
- Mario Kart: Double Dash
- The Legend of Zelda: Wind Waker (full game and demo)
- The Legend of Zelda: Twilight Princess
- Super Smash Bros. Melee
- Animal Crossing
- Resident Evil 4
- Metal Gear Solid: The Twin Snakes
- Ultimate Spider-Man
- Starfox Assault

Devolution uses parts of the lwBT Bluetooth stack:
/*
 * Copyright (c) 2003 EISLAB, Lulea University of Technology.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 */
