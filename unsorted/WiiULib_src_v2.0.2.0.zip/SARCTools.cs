﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using WiiULib.Extras;
using WiiULib.Filetypes;
using WiiULib.Helpers;

namespace WiiULib
{
    /// <summary>
    /// Tools related to the SARC file format.
    /// </summary>
    public static class SARCTools
    {
        /// <summary>
        /// Delete files from a SARC arhcive.
        /// </summary>
        /// <param name="filename">The input and output SARC file.</param>
        /// <param name="filesandfolderstodelete">The files and folders to delete.</param>
        public static void Delete(string filename, string[] filesandfolderstodelete)
        {
            Pack(filename, null, false, true, "", filesandfolderstodelete);
        }

        /// <summary>
        /// Opens a SARC file. Does not include SARC file data in output.
        /// </summary>
        /// <param name="filename">The SARC file to open.</param>
        /// <param name="sarc">When this method returns and the opened file is not invalid, a SARC struct for it excluding file data.</param>
        /// <returns>Whether the file is valid, incomplete, or invalid.</returns>
        public static CafeFileOpenResult Open(string filename, out SARC sarc)
        {
            if (!File.Exists(filename))
            {
                Console.WriteLine("[SARCTool] {0} does not exist", filename);
                sarc = new SARC();
                return CafeFileOpenResult.Invalid;
            }

            using (FileStream inputstream = new FileStream(filename, FileMode.Open))
            {
                return Open(inputstream, out sarc, true);
            }
        }

        /// <summary>
        /// Pack a folder into a SARC archive.
        /// </summary>
        /// <param name="filename">The output SARC file.</param>
        /// <param name="inputdirectory">The folder that will be packed.</param>
        /// <param name="recursive">Whether to also pack subfolders of the input directory.</param>
        /// <param name="append">When set to true, append to any existing archive instead of overwriting with new data.</param>
        /// <param name="appendfolder">When appending, the folder to append to.</param>
        /// <param name="filesandfolderstodelete">Any files and folders to delete prior to packing.</param>
        /// <returns>How many files were packed, including original files if appending.</returns>
        public static int Pack(string filename, string inputfileordirectory, bool recursive = true, bool append = true, string appendfolder = "", string[] filesandfolderstodelete = null)
        {
            using (FileStream outputstream = new FileStream(filename, FileMode.OpenOrCreate))
            {
                Console.WriteLine("[SARCTool] Started packing {0}", filename);

                //Get files
                List<SARCFileInfo> inputfiles = new List<SARCFileInfo>();
                if (File.Exists(inputfileordirectory))
                {
                    inputfiles.Add((SARCFileInfo)new FileInfo(inputfileordirectory));
                    inputfiles[0].RelativeName = appendfolder + Path.GetFileName(inputfiles[0].FullName);
                }
                else if (Directory.Exists(inputfileordirectory))
                {
                    DirectoryInfo inputdirectoryinfo = new DirectoryInfo(inputfileordirectory);
                    inputfiles.AddRange(Array.ConvertAll(inputdirectoryinfo.GetFiles("*", recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly), item => (SARCFileInfo)item));
                    for (int i = 0; i < inputfiles.Count; i++)
                    {
                        inputfiles[i].RelativeName = appendfolder + inputfiles[i].FullName.Substring(inputdirectoryinfo.FullName.Length).Replace('\\', '/').TrimStart('/');
                    }
                }

                Console.WriteLine("[SARCTool] Found {0} file(s)", inputfiles.Count);

                long totalfilessize = 0;
                for (int i = 0; i < inputfiles.Count; i++)
                {
                    totalfilessize += inputfiles[i].Length;
                }

                SARC originalsarc = new SARC();
                FileStream tempstream = null;
                string tempfilename = filename + ".temp";
                if (append && File.Exists(filename))
                {
                    while (File.Exists(tempfilename))
                    {
                        tempfilename += "_";
                    }
                    if (filesandfolderstodelete == null)
                    {
                        filesandfolderstodelete = new string[0];
                    }

                    File.Copy(filename, tempfilename);
                    tempstream = new FileStream(tempfilename, FileMode.OpenOrCreate);

                    if (Open(tempstream, out originalsarc, true) == CafeFileOpenResult.Valid)
                    {
                        for (int i = 0; i < originalsarc.sfat.header.nodeCount; i++)
                        {
                            bool deletingfolder = false;
                            for (int j = 0; j < filesandfolderstodelete.Length; j++)
                            {
                                if (originalsarc.sfnt.nodeFileNames[i].StartsWith(filesandfolderstodelete[j]))
                                {
                                    deletingfolder = true;
                                }
                            }

                            if (!deletingfolder && Array.IndexOf(filesandfolderstodelete, originalsarc.sfnt.nodeFileNames[i]) < 0)
                            {
                                inputfiles.Add(new SARCFileInfo());
                                inputfiles[inputfiles.Count - 1].Length = originalsarc.sfat.nodeInfo[i].nodeDataEnd - originalsarc.sfat.nodeInfo[i].nodeDataStart;
                                inputfiles[inputfiles.Count - 1].RelativeName = originalsarc.sfnt.nodeFileNames[i];
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("[SARCTool] {0} is incomplete or invalid", inputfiles.Count);
                        return -1;
                    }
                }
                else if (!append && appendfolder != "")
                {
                    appendfolder = "";
                }

                //Prepare SARC
                SARC sarc;
                sarc.header = new SARCHeader();
                sarc.sfat = new SFAT();
                sarc.sfat.header = new SFATHeader();
                sarc.sfat.nodeInfo = new SFATNode[inputfiles.Count];
                sarc.sfnt = new SFNT();
                sarc.sfnt.header = new SFNTHeader();
                sarc.sfnt.nodeFileNames = new string[inputfiles.Count];

                //Move to starting data position
                int startingdataoffset = StructHelper.GetSizeOfStruct(sarc.header) + StructHelper.GetSizeOfStruct(sarc.sfat.header) + (StructHelper.GetSizeOfStruct(new SFATNode()) * inputfiles.Count) + StructHelper.GetSizeOfStruct(sarc.sfnt.header);
                for (int i = 0; i < inputfiles.Count; i++)
                {
                    startingdataoffset += inputfiles[i].RelativeName.Length + 1;
                    while (startingdataoffset % 4 != 0)
                    {
                        startingdataoffset++;
                    }
                }
                outputstream.Seek(startingdataoffset, SeekOrigin.Begin);

                //Write data to file and set node information
                int filespacked = 0;
                byte[] outputbuffer;
                for (int i = 0; i < inputfiles.Count; i++)
                {
                    sarc.sfat.nodeInfo[i].unknown2 = 1;

                    int filenamestringoffset = 0;
                    for (int j = 0; j < i; j++)
                    {
                        filenamestringoffset += inputfiles[j].RelativeName.Length + 1;
                        while (filenamestringoffset % 4 != 0)
                        {
                            filenamestringoffset++;
                        }
                    }
                    filenamestringoffset /= 4;
                    sarc.sfat.nodeInfo[i].filenameStringStart = new UInt24((uint)filenamestringoffset);

                    sarc.sfat.nodeInfo[i].nodeDataStart = (uint)outputstream.Position - sarc.header.dataStart;
                    if (inputfiles[i].IsFileInfo)
                    {
                        using (FileStream inputstream = new FileStream(inputfiles[i].FullName, FileMode.Open))
                        {
                            inputstream.CopyTo(outputstream);
                        }
                    }
                    else
                    {
                        CopyFileData(tempstream, outputstream, originalsarc.header.dataStart, originalsarc.sfat.nodeInfo[originalsarc.sfat.header.nodeCount - inputfiles.Count + i]);
                    }
                    sarc.sfat.nodeInfo[i].nodeDataEnd = (uint)outputstream.Position - sarc.header.dataStart;

                    sarc.sfnt.nodeFileNames[i] = inputfiles[i].RelativeName + "\0";
                    while (sarc.sfnt.nodeFileNames[i].Length % 4 != 0)
                    {
                        sarc.sfnt.nodeFileNames[i] += "\0";
                    }

                    if (i + 1 != inputfiles.Count)
                    {
                        while (outputstream.Position % 0x100 != 0)
                        {
                            outputstream.Position++;
                        }
                    }

                    filespacked++;
                    Console.WriteLine("[SARCTool] Packed {0} ({1} bytes)", Path.GetFileName(inputfiles[i].RelativeName), sarc.sfat.nodeInfo[i].nodeDataEnd - sarc.sfat.nodeInfo[i].nodeDataStart);
                }

                //Set header information
                sarc.header.magic = 0x53415243;
                sarc.header.headerLength = (ushort)StructHelper.GetSizeOfStruct(sarc.header);
                sarc.header.bom = 0xFEFF;
                sarc.header.fileSize = (uint)outputstream.Length;
                sarc.header.dataStart = (uint)startingdataoffset;
                sarc.header.unknown1 = 0x10000000;

                sarc.sfat.header.magic = 0x53464154;
                sarc.sfat.header.headerLength = (ushort)StructHelper.GetSizeOfStruct(sarc.sfat.header);
                sarc.sfat.header.nodeCount = (ushort)inputfiles.Count;
                sarc.sfat.header.unknown1 = 0x00000065;

                sarc.sfnt.header.magic = 0x53464E54;
                sarc.sfnt.header.headerLength = (ushort)StructHelper.GetSizeOfStruct(sarc.sfnt.header);

                //Write headers and tables to file
                outputstream.Seek(0, SeekOrigin.Begin);
                outputbuffer = StructHelper.GetByteArray<SARCHeader>(EndianHelper.StructToBigEndian(sarc.header));
                outputstream.Write(outputbuffer, 0, outputbuffer.Length);

                outputbuffer = StructHelper.GetByteArray<SFATHeader>(EndianHelper.StructToBigEndian(sarc.sfat.header));
                outputstream.Write(outputbuffer, 0, outputbuffer.Length);

                for (int i = 0; i < sarc.sfat.nodeInfo.Length; i++)
                {
                    outputbuffer = StructHelper.GetByteArray<SFATNode>(EndianHelper.StructToBigEndian(sarc.sfat.nodeInfo[i]));
                    outputstream.Write(outputbuffer, 0, outputbuffer.Length);
                }

                outputbuffer = StructHelper.GetByteArray<SFNTHeader>(EndianHelper.StructToBigEndian(sarc.sfnt.header));
                outputstream.Write(outputbuffer, 0, outputbuffer.Length);

                for (int i = 0; i < sarc.sfnt.nodeFileNames.Length; i++)
                {
                    outputbuffer = Encoding.ASCII.GetBytes(sarc.sfnt.nodeFileNames[i]);
                    outputstream.Write(outputbuffer, 0, outputbuffer.Length);
                }

                if (File.Exists(tempfilename))
                {
                    tempstream.Dispose();
                    File.Delete(tempfilename);
                }

                Console.WriteLine("[SARCTool] Finished packing {0}", filename);
                return filespacked;
            }
        }

        /// <summary>
        /// Extracts the specified SARC file's contents to a directory.
        /// </summary>
        /// <param name="filename">The SARC file to extract from.</param>
        /// <param name="outputdirectory">The directory to extract to.</param>
        /// <param name="recursive">Whether to also extract from SARC files inside the input file.</param>
        /// <param name="fileorfoldertoextract">The file or folder to extract. Specify null to extract everything.</param>
        /// <param name="outputfilename">If fileorfoldertoextract isn't null, you can extract it with any name. If outputfile is null, the default name is used.</param>
        /// <returns>How many files were extracted.</returns>
        public static int Unpack(string filename, string outputdirectory, bool recursive = false, string fileorfoldertoextract = null, string outputfilename = null)
        {
            return Unpack(filename, outputdirectory, recursive, fileorfoldertoextract, outputfilename, true);
        }

        private static void CopyFileData(Stream source, Stream destination, uint datastart, SFATNode node)
        {
            byte[] outputbuffer = new byte[1024 * 64];
            int totalbytesread = 0;
            int bytesread = 0;
            int filelength = (int)(node.nodeDataEnd - node.nodeDataStart);

            source.Seek(datastart + node.nodeDataStart, SeekOrigin.Begin);
            while ((bytesread = source.Read(outputbuffer, 0, Math.Min(outputbuffer.Length, filelength - totalbytesread))) > 0)
            {
                destination.Write(outputbuffer, 0, bytesread);
                totalbytesread += bytesread;
            }
        }

        private static CafeFileOpenResult Open(FileStream inputstream, out SARC sarc, bool verboseinvalid)
        {
            byte[] inputbuffer;
            ushort bom;
            bool incomplete = false;
            sarc = new SARC();

            Console.WriteLine("[SARCTool] Started opening {0}", inputstream.Name);

            //Make sure it's long enough
            if (inputstream.Length < StructHelper.GetSizeOfStruct(sarc.header))
            {
                if (verboseinvalid)
                {
                    Console.WriteLine("[SARCTool] {0} is not SARC", inputstream.Name);
                }

                inputstream.Close();
                return CafeFileOpenResult.Invalid;
            }

            //Read SARC header
            inputbuffer = new byte[StructHelper.GetSizeOfStruct(sarc.header)];
            inputstream.Read(inputbuffer, 0, inputbuffer.Length);
            sarc.header = StructHelper.GetStruct<SARCHeader>(inputbuffer);
            bom = sarc.header.bom;
            sarc.header = EndianHelper.SwapEndianStructIfNeeded(sarc.header, bom);

            if (BitConverter.ToUInt32(inputbuffer, 0) != (uint)CafeFiletype.SARC)
            {
                if (verboseinvalid)
                {
                    Console.WriteLine("[SARCTool] {0} is not SARC", inputstream.Name);
                }

                inputstream.Close();
                return CafeFileOpenResult.Invalid;
            }

            if (inputstream.Length < sarc.header.fileSize)
            {
                Console.WriteLine("[SARCTool] {0} seems incomplete, continuing anyway", inputstream.Name);
                incomplete = true;
            }

            //Read SFAT header
            inputbuffer = new byte[StructHelper.GetSizeOfStruct(sarc.sfat.header)];
            inputstream.Read(inputbuffer, 0, inputbuffer.Length);
            sarc.sfat.header = EndianHelper.SwapEndianStructIfNeeded(StructHelper.GetStruct<SFATHeader>(inputbuffer), bom);

            Console.WriteLine("[SARCTool] Found {0} node(s)", sarc.sfat.header.nodeCount);

            //Read SFAT item information
            inputbuffer = new byte[StructHelper.GetSizeOfStruct(new SFATNode())];
            sarc.sfat.nodeInfo = new SFATNode[sarc.sfat.header.nodeCount];
            for (int i = 0; i < sarc.sfat.nodeInfo.Length; i++)
            {
                inputstream.Read(inputbuffer, 0, inputbuffer.Length);
                sarc.sfat.nodeInfo[i] = EndianHelper.SwapEndianStructIfNeeded(StructHelper.GetStruct<SFATNode>(inputbuffer), bom);
            }

            //Read SFNT header
            inputbuffer = new byte[StructHelper.GetSizeOfStruct(sarc.sfnt.header)];
            inputstream.Read(inputbuffer, 0, inputbuffer.Length);
            sarc.sfnt.header = EndianHelper.SwapEndianStructIfNeeded(StructHelper.GetStruct<SFNTHeader>(inputbuffer), bom);

            //Read SFNT item file names
            long posaftersfntheader = inputstream.Position;
            sarc.sfnt.nodeFileNames = new string[sarc.sfat.header.nodeCount];
            for (int i = 0; i < sarc.sfnt.nodeFileNames.Length; i++)
            {
                inputstream.Seek(posaftersfntheader + (uint)sarc.sfat.nodeInfo[i].filenameStringStart * 4, SeekOrigin.Begin);
                StringBuilder tempstr = new StringBuilder();
                while (true)
                {
                    byte tempbyte = Convert.ToByte(inputstream.ReadByte());

                    if (tempbyte == 0x00)
                    {
                        sarc.sfnt.nodeFileNames[i] = tempstr.ToString();
                        break;
                    }

                    tempstr.Append((char)tempbyte);
                }
            }

            Console.WriteLine("[SARCTool] Finished opening {0}", inputstream.Name);
            return !incomplete ? CafeFileOpenResult.Valid : CafeFileOpenResult.Incomplete;
        }

        private static int Unpack(string filename, string outputdirectory, bool recursive, string fileorfoldertoextract, string outputfilename, bool verboseinvalid)
        {
            if (!File.Exists(filename))
            {
                Console.WriteLine("[SARCTool] {0} does not exist", filename);
                return -1;
            }

            using (FileStream inputstream = new FileStream(filename, FileMode.Open))
            {
                Console.WriteLine("[SARCTool] Started unpacking {0}", filename);

                SARC sarc;
                CafeFileOpenResult result = Open(inputstream, out sarc, verboseinvalid);

                if (result == CafeFileOpenResult.Invalid)
                {
                    return -1;
                }

                while (File.Exists(outputdirectory))
                {
                    outputdirectory += "_";
                }

                //Unpack files
                int filesextracted = 0;
                for (int i = 0; i < sarc.sfat.header.nodeCount; i++)
                {
                    string currentoutputfilename = Path.Combine(outputdirectory, sarc.sfnt.nodeFileNames[i]);
                    string currentoutputdirectory = Path.GetDirectoryName(currentoutputfilename).TrimStart('\\');

                    bool fileorfoldertoextractiscurrentfile = fileorfoldertoextract != null && !fileorfoldertoextract.EndsWith("/") && fileorfoldertoextract == sarc.sfnt.nodeFileNames[i];
                    bool fileorfoldertoextractiscurrentfolder = fileorfoldertoextract != null && fileorfoldertoextract.EndsWith("/") && sarc.sfnt.nodeFileNames[i].StartsWith(fileorfoldertoextract);

                    if (fileorfoldertoextractiscurrentfile && outputfilename != null)
                    {
                        currentoutputfilename = Path.Combine(outputdirectory, outputfilename);
                        currentoutputdirectory = Path.GetDirectoryName(currentoutputfilename).TrimStart('\\');
                    }

                    if (fileorfoldertoextractiscurrentfolder)
                    {
                        currentoutputfilename = Path.Combine(outputdirectory, sarc.sfnt.nodeFileNames[i].Substring(fileorfoldertoextract.Length));
                        currentoutputdirectory = Path.GetDirectoryName(currentoutputfilename).TrimStart('\\');
                    }

                    if (fileorfoldertoextract == null || fileorfoldertoextractiscurrentfile || fileorfoldertoextractiscurrentfolder)
                    {
                        if (currentoutputdirectory != string.Empty && !Directory.Exists(currentoutputdirectory))
                        {
                            Directory.CreateDirectory(currentoutputdirectory);
                        }

                        using (FileStream outputstream = new FileStream(currentoutputfilename, FileMode.OpenOrCreate))
                        {
                            CopyFileData(inputstream, outputstream, sarc.header.dataStart, sarc.sfat.nodeInfo[i]);
                        }

                        filesextracted++;
                        Console.WriteLine("[SARCTool] Unpacked {0} ({1} bytes)", currentoutputfilename, sarc.sfat.nodeInfo[i].nodeDataEnd - sarc.sfat.nodeInfo[i].nodeDataStart);

                        if (recursive)
                        {
                            CafeFiletype filetype = CommonTools.GetFileType(filename);
                            switch (filetype)
                            {
                                case CafeFiletype.SARC:
                                    Unpack(currentoutputfilename, outputdirectory, true, null, null, false);
                                    break;

                                case CafeFiletype.Yaz0:
                                    Yaz0Tools.Decompress(currentoutputfilename, currentoutputfilename + ".arc");
                                    if (CommonTools.GetFileType(filename) == CafeFiletype.SARC)
                                    {
                                        Unpack(currentoutputfilename, outputdirectory, true, null, null, false);
                                    }
                                    break;
                            }
                        }
                    }
                }

                Console.WriteLine("[SARCTool] Finished unpacking {0}", filename);
                return filesextracted;
            }
        }

        private class SARCFileInfo
        {
            private FileInfo _fileinfo = null;
            private long? _length = null;
            private string _relativeName = null;

            public string FullName
            {
                get
                {
                    if (_fileinfo != null)
                    {
                        return _fileinfo.FullName;
                    }
                    return null;
                }
            }

            public bool IsFileInfo
            {
                get
                {
                    return _fileinfo != null;
                }
            }

            public long Length
            {
                get
                {
                    if (_length != null)
                    {
                        return (long)_length;
                    }
                    else if (_fileinfo != null)
                    {
                        return _fileinfo.Length;
                    }
                    return -1;
                }
                set
                {
                    _length = value;
                }
            }

            public string RelativeName
            {
                get
                {
                    return _relativeName;
                }
                set
                {
                    _relativeName = value;
                }
            }

            public static explicit operator SARCFileInfo(FileInfo fileinfo)
            {
                SARCFileInfo sarcfileinfo = new SARCFileInfo();
                sarcfileinfo._fileinfo = fileinfo;
                return sarcfileinfo;
            }

            public static implicit operator FileInfo(SARCFileInfo sarcfileinfo)
            {
                return sarcfileinfo._fileinfo;
            }
        }
    }
}