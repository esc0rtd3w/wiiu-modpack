﻿using System.Runtime.InteropServices;
using WiiULib.Extras;

namespace WiiULib.Filetypes
{
    [StructLayout(LayoutKind.Sequential)]
    public struct SARC
    {
        public SARCHeader header;
        public SFAT sfat;
        public SFNT sfnt;
        public byte[] data;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SARCHeader
    {
        public uint magic; //"SARC"
        public ushort headerLength; //should always be 0x0014
        public ushort bom; //byte order mark, should always be 0xFEFF since the Wii U is big endian
        public uint fileSize;
        public uint dataStart;
        public uint unknown1; //always 0x01000000? u8 + u24?
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SFAT
    {
        public SFATHeader header;
        public SFATNode[] nodeInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SFATHeader
    {
        public uint magic; //"SFAT"
        public ushort headerLength; //should always be 0x000C
        public ushort nodeCount;
        public uint unknown1; //always 0x00000065?
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SFATNode
    {
        public uint unknown1; //hash of something, files are sorted by this
        public byte unknown2; //flag? always 0x01?
        public UInt24 filenameStringStart; //relative to end of SFNT header, divided by 4
        public uint nodeDataStart; //relative to data starting offset
        public uint nodeDataEnd; //relative to data starting offset
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SFNT
    {
        public SFNTHeader header;
        public string[] nodeFileNames; //null terminated strings, aligned by 4 bytes
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SFNTHeader
    {
        public uint magic; //"SFNT"
        public uint headerLength; //should always be 0x0008
    }
}