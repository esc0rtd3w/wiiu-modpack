﻿using System.Runtime.InteropServices;

namespace WiiULib.Filetypes
{
    [StructLayout(LayoutKind.Sequential)]
    public struct Yaz0
    {
        public Yaz0Header header;
        public byte[] data;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Yaz0Header
    {
        public uint magic; //"Yaz0"
        public uint uncompressedSize;
        private ulong padding;
    }
}