﻿using System;
using System.IO;
using WiiULib.Filetypes;
using WiiULib.Helpers;

namespace WiiULib
{
    /// <summary>
    /// Tools related to the SARC file format, based on thakis's yaz0dec.
    /// </summary>
    public static class Yaz0Tools
    {
        /// <summary>
        /// Opens a Yaz0 file. Does not include Yaz0 file data in output.
        /// </summary>
        /// <param name="filename">The SARC file to open.</param>
        /// <param name="sarc">When this method returns and the opened file is not invalid, a SARC struct for it excluding file data.</param>
        /// <returns>Whether the file is valid or invalid.</returns>
        public static CafeFileOpenResult Open(string filename, out Yaz0 yaz0)
        {
            if (!File.Exists(filename))
            {
                Console.WriteLine("[Yaz0Tool] {0} does not exist", filename);
                yaz0 = new Yaz0();
                return CafeFileOpenResult.Invalid;
            }

            CafeFileOpenResult result;
            using (FileStream inputstream = new FileStream(filename, FileMode.Open))
            {
                result = Open(inputstream, out yaz0);
            }
            return result;
        }

        private static CafeFileOpenResult Open(FileStream inputstream, out Yaz0 yaz0)
        {
            yaz0 = new Yaz0();

            Console.WriteLine("[Yaz0Tool] Started opening {0}", inputstream.Name);

            //Make sure it's long enough
            if (inputstream.Length < StructHelper.GetSizeOfStruct(yaz0.header))
            {
                Console.WriteLine("[Yaz0Tool] {0} is not Yaz0", inputstream.Name);
                inputstream.Close();
                return CafeFileOpenResult.Invalid;
            }

            byte[] inputbuffer = new byte[StructHelper.GetSizeOfStruct(yaz0.header)];
            inputstream.Read(inputbuffer, 0, inputbuffer.Length);
            yaz0.header = EndianHelper.SwapEndianStruct(StructHelper.GetStruct<Yaz0Header>(inputbuffer));

            if (BitConverter.ToUInt32(inputbuffer, 0) != (uint)CafeFiletype.Yaz0)
            {
                Console.WriteLine("[Yaz0Tool] {0} is not Yaz0", inputstream.Name);
                inputstream.Close();
                return CafeFileOpenResult.Invalid;
            }

            Console.WriteLine("[Yaz0Tool] Finished opening {0}", inputstream.Name);
            return CafeFileOpenResult.Valid;
        }

        /// <summary>
        /// Decompresses the specified Yaz0 file to another file.
        /// </summary>
        /// <param name="inputfilename">The Yaz0 file to open.</param>
        /// <param name="outputfilename"></param>
        /// <returns>Whether the decompression was successful.</returns>
        public static bool Decompress(string inputfilename, string outputfilename)
        {
            using (FileStream inputstream = new FileStream(inputfilename, FileMode.Open))
            {
                Yaz0 yaz0;
                CafeFileOpenResult result = Open(inputstream, out yaz0);

                if (result == CafeFileOpenResult.Invalid)
                {
                    return false;
                }

                using (FileStream outputstream = new FileStream(outputfilename, FileMode.OpenOrCreate))
                {
                    Console.WriteLine("[Yaz0Tool] Started decompressing {0}", inputfilename);

                    uint validbitcount = 0;
                    byte currcodebyte = 0;
                    while (outputstream.Position < yaz0.header.uncompressedSize)
                    {
                        if (validbitcount == 0)
                        {
                            currcodebyte = (byte)inputstream.ReadByte();
                            validbitcount = 8;
                        }

                        if ((currcodebyte & 0x80) != 0)
                        {
                            outputstream.WriteByte((byte)inputstream.ReadByte());
                        }
                        else
                        {
                            byte byte1 = (byte)inputstream.ReadByte();
                            byte byte2 = (byte)inputstream.ReadByte();

                            int dist = ((byte1 & 0xF) << 8) | byte2;
                            int copysource = (int)outputstream.Position - (dist + 1);

                            int numbytes = byte1 >> 4;
                            if (numbytes == 0)
                            {
                                numbytes = (byte)inputstream.ReadByte() + 0x12;
                            }
                            else
                            {
                                numbytes += 2;
                            }

                            for (int i = 0; i < numbytes; i++)
                            {
                                int prevposition = (int)outputstream.Position;
                                outputstream.Seek(copysource + i, SeekOrigin.Begin);
                                byte sourcebyte = (byte)outputstream.ReadByte();
                                outputstream.Seek(prevposition, SeekOrigin.Begin);
                                outputstream.WriteByte(sourcebyte);
                            }
                        }

                        currcodebyte <<= 1;
                        validbitcount--;
                    }
                }

                Console.WriteLine("[Yaz0Tool] Decompressed {0} ({1} bytes)", outputfilename, yaz0.header.uncompressedSize);
            }

            Console.WriteLine("[Yaz0Tool] Finished decompressing {0}", inputfilename);
            return true;
        }
    }
}