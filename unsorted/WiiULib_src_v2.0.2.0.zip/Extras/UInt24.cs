﻿using System.Runtime.InteropServices;

namespace WiiULib.Extras
{
    [StructLayout(LayoutKind.Sequential)]
    public struct UInt24
    {
        private byte _a;
        private byte _b;
        private byte _c;

        public UInt24(uint value)
        {
            _a = (byte)(value & 0xFF);
            _b = (byte)(value >> 8);
            _c = (byte)(value >> 16);
        }

        public static explicit operator uint (UInt24 value)
        {
            return value._a | (uint)(value._b << 8) | (uint)(value._c << 16);
        }
    }
}