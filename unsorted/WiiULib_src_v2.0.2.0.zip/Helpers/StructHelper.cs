﻿using System;
using System.Runtime.InteropServices;

namespace WiiULib.Helpers
{
    internal static class StructHelper
    {
        public static int GetSizeOfStruct(object obj)
        {
            return Marshal.SizeOf(obj);
        }

        public static byte[] GetByteArray<T>(object obj)
        {
            int size = GetSizeOfStruct(obj);
            byte[] bytes = new byte[size];

            IntPtr intptr = Marshal.AllocHGlobal(size);

            Marshal.StructureToPtr(obj, intptr, true);
            Marshal.Copy(intptr, bytes, 0, size);
            Marshal.FreeHGlobal(intptr);

            return bytes;
        }

        public static T GetStruct<T>(byte[] bytes) where T : new()
        {
            T data = new T();

            int size = GetSizeOfStruct(data);
            IntPtr intptr = Marshal.AllocHGlobal(size);

            Marshal.Copy(bytes, 0, intptr, size);

            data = (T)Marshal.PtrToStructure(intptr, data.GetType());
            Marshal.FreeHGlobal(intptr);

            return data;
        }
    }
}