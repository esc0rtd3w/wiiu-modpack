﻿using System;
using System.Reflection;
using WiiULib.Extras;

namespace WiiULib.Helpers
{
    internal static class EndianHelper
    {
        public static T SwapEndianStructIfNeeded<T>(T obj, ushort bom)
        {
            if (((bom & 0xFF) == 0xFE && bom >> 8 == 0xFF && BitConverter.IsLittleEndian) || (bom & 0xFF) == 0xFF && bom >> 8 == 0xFE && !BitConverter.IsLittleEndian)
            {
                return SwapEndianStruct(obj);
            }

            return obj;
        }

        public static T StructToBigEndian<T>(T obj)
        {
            if (BitConverter.IsLittleEndian)
            {
                return SwapEndianStruct(obj);
            }

            return obj;
        }

        public static T StructToLittleEndian<T>(T obj)
        {
            if (!BitConverter.IsLittleEndian)
            {
                return SwapEndianStruct(obj);
            }

            return obj;
        }

        public static T SwapEndianStruct<T>(T obj)
        {
            object boxed = obj;
            foreach (FieldInfo field in boxed.GetType().GetFields())
            {
                Type fieldtype = field.FieldType;
                object fieldval = field.GetValue(boxed);

                if (fieldtype == typeof(ushort))
                {
                    byte[] bytes = BitConverter.GetBytes((ushort)fieldval);
                    Array.Reverse(bytes);
                    fieldval = BitConverter.ToUInt16(bytes, 0);
                }
                else if (fieldtype == typeof(uint))
                {
                    byte[] bytes = BitConverter.GetBytes((uint)fieldval);
                    Array.Reverse(bytes);
                    fieldval = BitConverter.ToUInt32(bytes, 0);
                }
                else if (fieldtype == typeof(UInt24))
                {
                    byte[] bytes = BitConverter.GetBytes((uint)(UInt24)fieldval);

                    if (BitConverter.IsLittleEndian)
                    {
                        Array.Copy(bytes, 0, bytes, 1, bytes.Length - 1);
                    }
                    else
                    {
                        Array.Copy(bytes, 1, bytes, 0, bytes.Length - 1);
                    }

                    Array.Reverse(bytes);
                    fieldval = new UInt24(BitConverter.ToUInt32(bytes, 0));
                }
                else if (fieldtype == typeof(ulong))
                {
                    byte[] bytes = BitConverter.GetBytes((ulong)fieldval);
                    Array.Reverse(bytes);
                    fieldval = BitConverter.ToUInt64(bytes, 0);
                }

                field.SetValue(boxed, fieldval);
            }

            return (T)boxed;
        }
    }
}