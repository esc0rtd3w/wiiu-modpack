﻿using System;
using System.IO;
using System.Linq;

namespace WiiULib
{
    /// <summary>
    /// The state of a file that was opened.
    /// </summary>
    public enum CafeFileOpenResult
    {
        Valid,
        Invalid,
        Incomplete
    }

    /// <summary>
    /// Tools not related to a specific file format.
    /// </summary>
    public static class CommonTools
    {
        /// <summary>
        /// Get the Wii U-related filetype of a file.
        /// </summary>
        /// <param name="filename">The filename to check.</param>
        /// <returns>The detected filetype.</returns>
        public static CafeFiletype GetFileType(string filename)
        {
            using (FileStream inputstream = new FileStream(filename, FileMode.Open))
            {
                if (inputstream.Length >= 4)
                {
                    byte[] buffer = new byte[4];
                    inputstream.Read(buffer, 0, buffer.Length);

                    if (BitConverter.IsLittleEndian)
                    {
                        buffer.Reverse();
                    }

                    uint magic = BitConverter.ToUInt32(buffer, 0);
                    if (Enum.IsDefined(typeof(CafeFiletype), magic))
                    {
                        return (CafeFiletype)magic;
                    }
                }
            }

            return CafeFiletype.Unknown;
        }
    }

    /// <summary>
    /// Wii U filetype magic IDs.
    /// </summary>
    public enum CafeFiletype : uint
    {
        Unknown,
        SARC = 0x43524153,
        Yaz0 = 0x307A6159
    }
}