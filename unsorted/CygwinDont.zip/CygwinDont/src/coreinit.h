//VER=500
#define OSDynLoad_Acquire ((void (*)(char* rpl, unsigned int *handle))0x1029CD8)
#define OSDynLoad_FindExport ((void (*)(unsigned int handle, int isdata, char *symbol, void *address))0x102B3E4)
#define OSFatal ((void (*)(char* msg))0x1030ECC)
#define __os_snprintf ((int(*)(char* s, int n, const char * format, ... ))0x102ECE0)