#include "coreinit.h"

void start()
{
    OSFatal("Hello on 5.x");
}