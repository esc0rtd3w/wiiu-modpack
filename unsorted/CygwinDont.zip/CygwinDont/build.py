import os,sys,platform
import subprocess

path=os.path.dirname(os.path.realpath(sys.argv[0]))
os.chdir(path+"/build")
gcc='powerpc-eabi-gcc' #change to 'C:\devkitPro\devkitPPC\bin\powerpc-eabi-gcc.exe' if this doesn't work
ld ='powerpc-eabi-ld'  #change to 'C:\devkitPro\devkitPPC\bin\powerpc-eabi-ld.exe'  if this doesn't work

argc=len(sys.argv)
ar1=""
ar2=""

try:
	ar1=sys.argv[1]
	ar2=sys.argv[2]
except:
	pass

if argc > 1:
	filename=ar1
else:
    filename="hello"

if argc > 2:
	ver=ar2
else:
    ver="500"
    
platform=platform.system().lower()
print("Building for your "+platform+" platform...")

if  not os.path.isfile("findcode"+ver+".bin"):
	# Build findcode
	os.system(gcc+" -nostdinc -fno-builtin -VER="+ver+" -c ../src/findcode"+ver+".c")
	os.system(ld+" -Ttext 1800000 --oformat binary -o findcode"+ver+".bin findcode"+ver+".o")
	# Get rid of GCC function prologue and move stack out of our buffer
	# Result should start with: 94 21 E0 00 7C 3F 0B 78 3D 20 1D D7 61 29 B8 14
	os.system("dd if=findcode"+ver+".bin of=findcode"+ver+".bin bs=4 obs=4 skip=5 count=1 conv=notrunc")
	os.system("dd if=findcode"+ver+".bin of=findcode"+ver+".bin bs=4 obs=4 skip=4 seek=1 count=1 conv=notrunc") 
	os.system("dd if=findcode"+ver+".bin of=findcode"+ver+".bin bs=4 obs=4 skip=6 seek=2 conv=notrunc")
   
if ver == "400":
    os.system("dd if=findcode"+ver+".bin of=stack"+ver+".bin obs=352 seek=1 conv=notrunc")
else:
    os.system("dd if=findcode"+ver+".bin of=stack"+ver+".bin obs=432 seek=1 conv=notrunc")

os.system(gcc+" -nostdinc -fno-builtin -c ../src/"+filename+".c")
os.system(ld+" -Ttext 1800000 --oformat binary -o code.bin "+filename+".o")



file = open("../test"+ver+".html", 'w+')
file.write(os.popen("python generate_html.py "+ver+"").read());
f=open("../test"+ver+".html","r")
page=f.read()

if platform=='windows':
	output=open("test"+ver+".html","w")
	output.write(page) # ' \x ' causes trouble in windows so \\ was needed
	#output=open("C:\wamp\www\wiiu\index.html","w") # my wamp setup
	#output.write(page)
else:
	output=open("/opt/lampp/htdocs/test"+ver+".html","w")
	output.write(page)

f.close()
output.close()