
REQUIREMENTS

HARDWARE

WiiU (5.5.1 FW or lower)
SD Card (16GB suggested minimum. 32GB suggested. 256GB max.)
USB hard drive or flash drive (This will hold your games. 2TB max)
SD card / usb: Must be be able to hold your installation game (1 - 7 GB) - 1 game at a time.

----------------------------------------------------------------------------------

SOFTWARE

SD formatter: https://www.sdcard.org/downloads/formatter_4/eula_windows/index.html OR http://www.ridgecrop.demon.co.uk/index.htm?fat32format.htm
DO NOT NAME YOUR SD CARDS "WIIU" NAME IT "SDCARD"

Starter pack: https://drive.google.com/file/d/0BzJAGHWBJ_5sOXdIUU9XeF9HUTA/view

uTikDownloadHelper: https://github.com/DanTheMan827/uTikDownloadHelper/releases - this downloads your game and the modified ticket

Wupinstaller-mod - https://github.com/Yardape8000/wupinstaller/releases - installation .elf file to run on your WiiU

----------------------------------------------------------------------------------

ON THE COMPUTER

1. Launch uTikDownloadHelper - answer the question hint: google "wiiu ticket database"
2. Select your region > select your game > download to a new folder in your desired location - this will be the full game with the modified ticket already present
3. Rename the title folder to just "install"
4. Put the "install" folder on the root of your SD card

----------------------------------------------------------------------------------

IF YOU ALREADY HAVE SAVES FOR YOUR GAMES AND NEED TO MOVE THEM OVER TO YOUR USB GAMES - SKIP THIS IF YOU DON'T HAVE SAVEGAMES YOU WOULD LIKE TO TRANSFER.

DUMPING

1. Unzip the saviine 1.1b folder
2. Move the saviine folder to the root of any hard drive such as C:
3. Put the saviine folder in the wiiu/apps/ folder on your SD card.
4. Launch the server on your computer (dump.bat) - this may prompt a firewall rule to be created - accept it on private networks (your home network)
5. Launch saviine on your WiiU by launching the web-browser and going to http://loadiine.ovh - launch the homebrew browser.
6. Set the IP address for your computer (if you don't know it go to start > type "cmd" then "ipconfig") Install saviine and go to the home menu.
7. Insert your game disc into the WiiU and load your game.
8. Before the game launches it will freeze and send the save data to the listening server on your computer
9. The save will be mapped to the title ID for your game. 

INJECTING

1. Dump your save as explained above.
2. Delete the old game/saves from your console 
3. Follow the instructions below for USB installation and then return to step 4.
4. AFTER you have installed your USB game go into the loadiine folder on your computer on your C: drive
5. Load up your saviine server using (inject.bat) Put the dumped save into the inject folder.
6. Load saviine and go back to the menu as explained above in steop 5-6 in the dumping process.
7. Load your USB game 
8. On your computer you will be prompted as to what files you want to install
9. Select your common file and save file and install
10. The server will transfer the files to your console while the game stays frozen
11. Upon completion your game will load as normal. - verify that your save has all of your data / tropies / etc.

PROFIT.
----------------------------------------------------------------------------------

ON THE CONSOLE - USB INSTALLATION

PRE-INSTALL
0. Format your USB flash drive using the WiiU's format option - this should pop up automatically if it's your first time plugging in the USB storage device.

SAFETY - disable updates / automatic updates
1. Disable automatic updates
2. Disable standby mode
3. Connect to wifi
4. Change DNS: to manual
	Primary DNS: 107.211.140.065 (TubeHax DNS)
	Secondary DNS: 104.236.072.203 (chncdcksn hax)

LOAD THE GAMES

1. WiiU Browser
	 http://loadiine.ovh
2. Load the exploit for your Wii U's version
3. Load WUP installer mod
4. Press X - DO NOT DO ANYTHING. The game may install multiple times or display a random percentage such as 300% - THIS IS NORMAL. 
5. When the installation is finished you will have a message on the screen telling you so.
6. press home > this will load the mii maker > press home and close > you're back on the main screen
7. Launch your game and test it. 
8. If you have saves you would like to transfer from your disc games to USB read the information above on how to dump your games.

--------------------------------------------------------------------------------------



