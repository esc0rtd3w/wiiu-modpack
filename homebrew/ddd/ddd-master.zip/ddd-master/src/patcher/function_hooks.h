#ifndef _FUNCTION_HOOKS_H_
#define _FUNCTION_HOOKS_H_

#ifdef __cplusplus
extern "C" {
#endif

void PatchMethodHooks(void);
void RestoreInstructions(void);

#ifdef __cplusplus
}
#endif

#endif /* _FS_H */
