# tik2sd
easly dump wiiu tickets to your sd card

# Dependencies
To properly compile this project yourself you will need the latest libiosuhax from dimok789's github.  