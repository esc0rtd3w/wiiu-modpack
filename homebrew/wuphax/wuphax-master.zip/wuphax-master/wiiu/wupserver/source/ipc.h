#ifndef _IPC_H_
#define _IPC_H_

void ipc_init();

#endif
