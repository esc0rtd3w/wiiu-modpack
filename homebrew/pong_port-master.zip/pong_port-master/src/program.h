#ifndef PROGRAM_H
#define PROGRAM_H

//Using modified version of draw to render at twice the scale to improve framerate
#include "draw.h"

#include "pong.h"

int _entryPoint();

#endif /* PROGRAM_H */
