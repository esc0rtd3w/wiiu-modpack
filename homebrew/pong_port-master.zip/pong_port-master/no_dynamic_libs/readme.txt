The files in this folder go into libwiiu/osscreenexamples/pong path to make compilation possible.
