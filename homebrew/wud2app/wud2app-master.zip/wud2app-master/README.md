# wud2app
convert wudump folders and .wud images into cert, tik, tmd and app files
