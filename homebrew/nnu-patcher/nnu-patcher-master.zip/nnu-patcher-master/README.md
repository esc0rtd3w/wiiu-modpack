#I AM NOT RESPONSIBLE FOR ANY CONSOLE UPDATES OR BROKEN CONSOLES, USE THIS AT YOUR OWN RISK!  

# NNU Patcher
A WiiU patcher for NeedsNetworkUpdate to use the eShop.

# Usage
Copy the the content of the "htmls" folder into a new folder on your webserver, run OSDriver for kernel access, start NNU Patcher and enjoy using the eShop temporarily!

# Limitations
This patch is only active if you use the webpage and directly enter the eShop. After exiting it, shutting down, rebooting etc the patch will be gone and it will ask you again to update your system.
It will only work properly if you have updated your version.bin with wupinstaller, else a similar update message will appear.
Only 5.3.2 is supported by wupinstaller, limiting this patch to 5.3.2 as well.