# WiiU VC Inject
Get SNES, GBA and NDS files into WiiU VC.

# Usage
Download yourself a copy of this repository.  
Edit the "ip.txt" in "bin" to the IP of your WiiU.  
Execute the Kernel Exploit and install TCPGecko on your WiiU.  
Start your SNES/GBA/NDS VC game, go into the VC Menu and drag and drop the file of your choice into "bin/wiiu-vc-inject.exe".  
Select reset game in the VC Menu and if everything went well you are now in your game of choice!  

# Manual Compiling
As of right now this is a windows only code. If you have MinGW installed and gcc referenced in your PATH variable just use the "build.bat".  
Support for other OSes might follow in the future.
