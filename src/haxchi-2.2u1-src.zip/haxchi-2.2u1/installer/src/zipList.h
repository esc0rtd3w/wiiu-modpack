
#ifndef _ZIPLIST_H_
#define _ZIPLIST_H_

extern u8 animalcrossing_zip[]; extern u32 animalcrossing_zip_size;
extern u8 bigbrainacademy_zip[]; extern u32 bigbrainacademy_zip_size;
extern u8 brainage_zip[]; extern u32 brainage_zip_size;
extern u8 dkjclimber_zip[]; extern u32 dkjclimber_zip_size;
extern u8 explorersofsky_zip[]; extern u32 explorersofsky_zip_size;
extern u8 guardiansigns_zip[]; extern u32 guardiansigns_zip_size;
extern u8 kirby_zip[]; extern u32 kirby_zip_size;
extern u8 kirbycanvascurse_zip[]; extern u32 kirbycanvascurse_zip_size;
extern u8 kirbymassattack_zip[]; extern u32 kirbymassattack_zip_size;
extern u8 mariokartds_zip[]; extern u32 mariokartds_zip_size;
extern u8 masterofdisguise_zip[]; extern u32 masterofdisguise_zip_size;
extern u8 newsmb_zip[]; extern u32 newsmb_zip_size;
extern u8 newsmb_eur_zip[]; extern u32 newsmb_eur_zip_size;
extern u8 partnersintime_zip[]; extern u32 partnersintime_zip_size;
extern u8 pokemonranger_zip[]; extern u32 pokemonranger_zip_size;
extern u8 shadowsofalmia_zip[]; extern u32 shadowsofalmia_zip_size;
extern u8 sfcommand_zip[]; extern u32 sfcommand_zip_size;
extern u8 sm64ds_zip[]; extern u32 sm64ds_zip_size;
extern u8 wwtouched_zip[]; extern u32 wwtouched_zip_size;
extern u8 yoshids_zip[]; extern u32 yoshids_zip_size;
extern u8 yoshitouchandgo_zip[]; extern u32 yoshitouchandgo_zip_size;
extern u8 zeldaph_zip[]; extern u32 zeldaph_zip_size;
extern u8 zeldast_zip[]; extern u32 zeldast_zip_size;

#endif
