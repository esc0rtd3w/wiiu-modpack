#ifndef _UTILS_H_
#define _UTILS_H_

void* m_memcpy(void *dst, const void *src, unsigned int len);
void* m_memset(void *dst, int val, unsigned int len);

#endif
