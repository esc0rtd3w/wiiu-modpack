
#ifndef _RELOAD_H_
#define _RELOAD_H_

void kernel_launch_ios(u32 launch_address, u32 L, u32 C, u32 H);

#endif
