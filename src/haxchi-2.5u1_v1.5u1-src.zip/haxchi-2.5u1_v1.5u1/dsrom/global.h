
#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#define LAUNCH_SYSMENU 0
#define LAUNCH_HBL 1
#define LAUNCH_MOCHA 2
#define LAUNCH_CFW_IMG 3

#endif
