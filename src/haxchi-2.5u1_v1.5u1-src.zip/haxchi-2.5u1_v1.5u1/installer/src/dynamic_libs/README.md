# dynamic_libs
Dynamic libs for WiiU homebrew
