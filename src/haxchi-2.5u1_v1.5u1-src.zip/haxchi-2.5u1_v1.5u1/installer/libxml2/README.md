Built from libxml2-2.9.4 with the following config:  
./autogen.sh --disable-shared --enable-static --with-minimum=yes --with-output=yes --host=powerpc-eabi