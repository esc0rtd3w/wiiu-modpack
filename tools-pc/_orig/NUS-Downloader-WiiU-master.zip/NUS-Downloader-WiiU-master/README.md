Modified NUS Downloader (http://code.google.com/p/nusdownloader/) for downloading Wii U updates.

Put the Wii U common key in NUS Downloader/CommonKey.cs , build, then try downloading any title from the list at http://wiiubrew.org/wiki/Title_database .

(note that the Wiiubrew page has a dash in the title ID; you need to remove that.)

This is pretty much useless for you if you're not a reverse engineer, I guess? It's certainly useless for me :(