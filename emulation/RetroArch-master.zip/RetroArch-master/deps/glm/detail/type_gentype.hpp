///////////////////////////////////////////////////////////////////////////////////
/// OpenGL Mathematics (glm.g-truc.net)
///
/// Copyright (c) 2005 - 2014 G-Truc Creation (www.g-truc.net)
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
/// 
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
/// 
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.
///
/// @ref core
/// @file glm/core/type_gentype.hpp
/// @date 2008-10-05 / 2011-06-15
/// @author Christophe Riccio
///////////////////////////////////////////////////////////////////////////////////

#ifndef glm_core_type_gentype
#define glm_core_type_gentype

namespace glm
{
	enum profile
	{
		nice,
		fast,
		simd
	};

	typedef std::size_t sizeType;
	
namespace detail
{
	template
	<
		typename VALTYPE, 
		template <typename> class TYPE
	>
	struct genType
	{
	public:
		enum ctor{null};

		typedef VALTYPE value_type;
		typedef VALTYPE & value_reference;
		typedef VALTYPE * value_pointer;
		typedef VALTYPE const * value_const_pointer;
		typedef TYPE<bool> bool_type;

		typedef sizeType size_type;
		static bool is_vector();
		static bool is_matrix();
		
		typedef TYPE<VALTYPE> type;
		typedef TYPE<VALTYPE> * pointer;
		typedef TYPE<VALTYPE> const * const_pointer;
		typedef TYPE<VALTYPE> const * const const_pointer_const;
		typedef TYPE<VALTYPE> * const pointer_const;
		typedef TYPE<VALTYPE> & reference;
		typedef TYPE<VALTYPE> const & const_reference;
		typedef TYPE<VALTYPE> const & param_type;

		//////////////////////////////////////
		// Address (Implementation details)

		value_const_pointer value_address() const{return value_pointer(this);}
		value_pointer value_address(){return value_pointer(this);}

	//protected:
	//	enum kind
	//	{
	//		GEN_TYPE,
	//		VEC_TYPE,
	//		MAT_TYPE
	//	};

	//	typedef typename TYPE::kind kind;
	};

	template
	<
		typename VALTYPE, 
		template <typename> class TYPE
	>
	bool genType<VALTYPE, TYPE>::is_vector()
	{
		return true;
	}
}//namespace detail
}//namespace glm

//#include "type_gentype.inl"

#endif//glm_core_type_gentype
